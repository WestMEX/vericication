#!/usr/bin/env python3
"""
=============================================================
  VAULT AUTH — Programador de chips NFC para gorras
=============================================================
  Requiere:
    pip install nfcpy   (para NFC real)
    pip install qrcode  (para generar QR de respaldo)

  Si no tienes lector NFC físico, el script genera la URL
  que debes escribir manualmente con cualquier app NFC
  (NFC Tools, NXP TagWriter, etc.)

  CHIP RECOMENDADO: NTAG213/215/216 o NXP ICODE SLI
  - UID de 7 bytes (único de fábrica, no se puede clonar)
  - NDEF record tipo URL
  - Bloquear escritura después de programar (OTP bits)
=============================================================
"""

import hashlib
import hmac
import json
import os
import sys
import time
import uuid
from datetime import datetime

# ─── CONFIGURACIÓN ────────────────────────────────────────
BASE_URL     = "https://TU_USUARIO.github.io/TU_REPO/"
DB_FILE      = "db.json"        # Base de datos local de productos
SECRET_SALT  = "CAMBIA_ESTO_POR_UNA_CADENA_SECRETA_LARGA_Y_RANDOM"

# ─── UTILIDADES CRIPTOGRÁFICAS ────────────────────────────

def generate_hmac(uid: str, secret: str) -> str:
    """Genera firma HMAC-SHA256 del UID con el secret del producto."""
    key = (secret + SECRET_SALT).encode()
    msg = uid.encode()
    return hmac.new(key, msg, hashlib.sha256).hexdigest()

def generate_product_secret(uid: str) -> str:
    """Genera un secret único por producto basado en el UID."""
    return hmac.new(
        SECRET_SALT.encode(),
        uid.encode(),
        hashlib.sha256
    ).hexdigest()[:32]

def build_nfc_url(uid: str, sig: str) -> str:
    """Construye la URL que irá en el chip NFC."""
    return f"{BASE_URL}?uid={uid}&sig={sig}"

# ─── BASE DE DATOS ────────────────────────────────────────

def load_db() -> dict:
    if os.path.exists(DB_FILE):
        with open(DB_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_db(db: dict):
    with open(DB_FILE, 'w') as f:
        json.dump(db, f, indent=2, ensure_ascii=False)
    print(f"  ✓ Base de datos guardada en '{DB_FILE}'")

def register_product(uid: str, model: str, batch: str, color: str, size: str) -> dict:
    """Registra un producto nuevo en la base de datos."""
    db = load_db()

    if uid in db:
        print(f"  ⚠  UID '{uid}' ya está registrado.")
        return db[uid]

    secret = generate_product_secret(uid)
    sig    = generate_hmac(uid, secret)

    product = {
        "uid":     uid,
        "model":   model,
        "batch":   batch,
        "color":   color,
        "size":    size,
        "created": datetime.now().strftime("%Y-%m"),
        "secret":  uid + "_vault_secret",   # debe coincidir con el JS
        "sig":     sig,
        "url":     build_nfc_url(uid, sig),
        "scans":   []
    }

    db[uid] = product
    save_db(db)
    return product

# ─── ESCRITURA NFC ────────────────────────────────────────

def write_nfc_real(url: str):
    """
    Escribe la URL en un chip NFC físico usando nfcpy.
    Conecta el lector USB/GPIO antes de ejecutar.
    """
    try:
        import nfc
        import ndef

        def on_connect(tag):
            print(f"  → Chip detectado: {tag}")
            print(f"     UID físico: {tag.identifier.hex().upper()}")

            record = ndef.UriRecord(url)
            tag.ndef.records = [record]

            # BLOQUEAR escritura (protege contra re-escritura / clonación)
            # Descomenta la siguiente línea en producción:
            # tag.protect()

            print(f"  ✓ URL escrita correctamente")
            print(f"     {url}")
            return True

        with nfc.ContactlessFrontend('usb') as clf:
            print("  Acerca el chip NFC al lector...")
            clf.connect(rdwr={'on-connect': on_connect})

    except ImportError:
        print("  [!] nfcpy no instalado. Usa: pip install nfcpy")
        print("      Escribe la URL manualmente con NFC Tools app:")
        print(f"      {url}")
    except Exception as e:
        print(f"  [!] Error NFC: {e}")
        print(f"      URL para escritura manual: {url}")

def write_nfc_manual_instructions(uid: str, url: str):
    """Imprime instrucciones para escribir manualmente con app NFC."""
    print()
    print("=" * 60)
    print("  INSTRUCCIONES — ESCRITURA MANUAL CON APP NFC TOOLS")
    print("=" * 60)
    print()
    print("  App recomendada: 'NFC Tools' (Android/iOS)")
    print()
    print("  1. Abre NFC Tools → WRITE → Add a record → URL/URI")
    print(f"  2. Pega esta URL exactamente:")
    print()
    print(f"     {url}")
    print()
    print("  3. Acerca el chip y pulsa 'Write'")
    print("  4. IMPORTANTE: Activa 'Read-only' para bloquear el chip")
    print("     (en NFC Tools: Write → Make read-only)")
    print()
    print("  UID registrado:", uid)
    print("=" * 60)

def generate_qr(url: str, uid: str):
    """Genera un QR de respaldo con la misma URL."""
    try:
        import qrcode
        img = qrcode.make(url)
        filename = f"qr_{uid}.png"
        img.save(filename)
        print(f"  ✓ QR generado: {filename}")
    except ImportError:
        print("  [!] qrcode no instalado. Usa: pip install qrcode[pil]")

# ─── VERIFICACIÓN LOCAL ───────────────────────────────────

def verify_locally(uid: str, sig: str) -> dict:
    """Simula la verificación que haría el navegador."""
    db = load_db()

    if uid not in db:
        return {"status": "FALSO", "reason": "UID no registrado"}

    product = db[uid]
    expected_sig = product.get("sig", "")

    if sig != expected_sig:
        return {"status": "FALSO", "reason": "Firma inválida — posible clonación"}

    # Registrar escaneo
    product["scans"].append({
        "ts":   int(time.time() * 1000),
        "date": datetime.now().isoformat(),
        "status": "OK"
    })
    save_db(db)

    return {
        "status":  "OK",
        "product": product,
        "scans":   len(product["scans"])
    }

# ─── MENÚ PRINCIPAL ───────────────────────────────────────

def menu():
    print()
    print("╔══════════════════════════════════════╗")
    print("║       VAULT AUTH — NFC TAGGER        ║")
    print("╠══════════════════════════════════════╣")
    print("║  1. Registrar y programar nueva gorra║")
    print("║  2. Ver base de datos                ║")
    print("║  3. Verificar UID localmente         ║")
    print("║  4. Generar URL de prueba            ║")
    print("║  0. Salir                            ║")
    print("╚══════════════════════════════════════╝")
    return input("  Opción: ").strip()

def flow_register():
    print()
    print("── REGISTRO DE NUEVA GORRA ──────────────")

    # En producción, el UID vendría del chip físico leído por el lector.
    # Aquí lo generamos o lo ingresamos manualmente.
    uid_input = input("  UID del chip (deja vacío para generar uno): ").strip()
    if not uid_input:
        uid_input = "GORRA-" + uuid.uuid4().hex[:8].upper()
        print(f"  → UID generado: {uid_input}")

    model  = input("  Modelo de gorra [Snapback Classic]: ").strip() or "Snapback Classic"
    batch  = input("  Lote [LOTE-2025-A]: ").strip() or "LOTE-2025-A"
    color  = input("  Color [Negro/Lima]: ").strip() or "Negro/Lima"
    size   = input("  Talla [Talla única]: ").strip() or "Talla única"

    product = register_product(uid_input, model, batch, color, size)

    print()
    print("  ✓ Producto registrado:")
    print(f"     UID:    {product['uid']}")
    print(f"     Modelo: {product['model']}")
    print(f"     URL:    {product['url']}")

    generate_qr(product['url'], product['uid'])

    use_nfc = input("\n  ¿Escribir en chip NFC ahora? [s/N]: ").strip().lower()
    if use_nfc == 's':
        write_nfc_real(product['url'])
    else:
        write_nfc_manual_instructions(product['uid'], product['url'])

def flow_view_db():
    db = load_db()
    if not db:
        print("  Base de datos vacía.")
        return
    print()
    print(f"  {'UID':<25} {'Modelo':<20} {'Lote':<15} {'Escaneos'}")
    print("  " + "─" * 70)
    for uid, p in db.items():
        scans = len(p.get('scans', []))
        print(f"  {uid:<25} {p.get('model',''):<20} {p.get('batch',''):<15} {scans}")

def flow_verify():
    uid = input("  UID a verificar: ").strip()
    sig = input("  Firma (sig): ").strip()
    result = verify_locally(uid, sig)
    print()
    if result["status"] == "OK":
        p = result["product"]
        print(f"  ✅ AUTÉNTICO — {p['model']} | {p['batch']} | Escaneos: {result['scans']}")
    else:
        print(f"  ❌ {result['status']} — {result['reason']}")

def flow_demo_url():
    db = load_db()
    if not db:
        print("  No hay productos en la base de datos. Registra uno primero.")
        return
    uid = list(db.keys())[0]
    product = db[uid]
    print()
    print("  URL de demostración (cópiala en tu navegador):")
    print()
    print(f"  {product['url']}")
    print()
    print("  O escanea el QR si lo generaste.")

# ─── ENTRY POINT ─────────────────────────────────────────

if __name__ == "__main__":
    # Si se pasan argumentos: python nfc_writer.py --uid X --sig Y
    if len(sys.argv) >= 5 and sys.argv[1] == '--verify':
        uid = sys.argv[2]
        sig = sys.argv[4]
        result = verify_locally(uid, sig)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        sys.exit(0)

    while True:
        opt = menu()
        if opt == '1': flow_register()
        elif opt == '2': flow_view_db()
        elif opt == '3': flow_verify()
        elif opt == '4': flow_demo_url()
        elif opt == '0': break
        else: print("  Opción no válida.")
        print()
